require('dotenv').config();
const line = require('@line/bot-sdk');
const express = require('express');

// ── 設定 ─────────────────────────────────────────────
const config = {
  channelAccessToken: process.env.LINE_CHANNEL_ACCESS_TOKEN,
  channelSecret:      process.env.LINE_CHANNEL_SECRET,
};

const ADMIN_LINE_USER_ID = process.env.ADMIN_LINE_USER_ID;

const app = express();
const client = new line.Client(config);

// ── セッション (本番はRedis推奨) ─────────────────────
const sessions = new Map();

const STEPS = {
  NAME: 'name',
  BIRTHDAY: 'birthday',
  TIMEOF: 'timeOfDay',
  BIRTHPLACE: 'birthplace',
  CONFIRM: 'confirm',
  DONE: 'done',
};

// ── Webhook ──────────────────────────────────────────
app.post('/webhook',
  line.middleware(config),
  async (req, res) => {
    res.sendStatus(200);
    await Promise.all(req.body.events.map(handleEvent));
  }
);

app.get('/', (_, res) => res.send('🌙 星読みカルテ LINE Bot 稼働中'));

// ── イベントハンドラ ──────────────────────────────────
async function handleEvent(event) {
  if (event.type === 'follow') {
    await sendWelcome(event.source.userId);
    return;
  }
  if (event.type !== 'message' || event.message.type !== 'text') return;

  const userId = event.source.userId;
  const text   = event.message.text.trim();
  const session = sessions.get(userId) || { step: null };

  // 未開始 or 完了後のキーワード反応
  if (!session.step || session.step === STEPS.DONE) {
    if (/診断|スタート|start|始め|はじめ/i.test(text)) {
      await sendWelcome(userId);
    }
    return;
  }

  await handleStep(userId, text, session);
}

// ── ステップ処理 ──────────────────────────────────────
async function handleStep(userId, text, session) {
  switch (session.step) {

    case STEPS.NAME: {
      if (!text || text.length > 20) {
        await push(userId, '1〜20文字で入力してください🌙');
        break;
      }
      session.name = text;
      session.step = STEPS.BIRTHDAY;
      sessions.set(userId, session);
      await push(userId,
        `${text}さん、ありがとうございます✨\n\n` +
        `次に、生年月日を教えてください🌟\n` +
        `例：1997/10/06 または 19971006`
      );
      break;
    }

    case STEPS.BIRTHDAY: {
      const date = parseBirthday(text);
      if (!date) {
        await push(userId,
          '日付の形式が合っていないようです🙏\n' +
          '例：1997/10/06 のように入力してください'
        );
        break;
      }
      session.birthday = date;
      session.zodiac   = getZodiac(date.month, date.day);
      session.step     = STEPS.TIMEOF;
      sessions.set(userId, session);

      await pushWithQR(userId,
        `${date.year}年${date.month}月${date.day}日ですね🌙\n（${session.zodiac}）\n\n` +
        `生まれた時間帯はわかりますか？\nアセンダント（上昇星座）の精度が上がります✨`,
        [
          { label: '🌅 朝（5〜12時）', text: '朝' },
          { label: '☀️ 昼（12〜18時）', text: '昼' },
          { label: '🌙 夜（18〜5時）',  text: '夜' },
          { label: 'わからない',        text: 'わからない' },
          { label: 'スキップ',          text: 'スキップ' },
        ]
      );
      break;
    }

    case STEPS.TIMEOF: {
      const valid = ['朝', '昼', '夜', 'わからない', 'スキップ'];
      session.timeOfDay = valid.includes(text) ? text : 'スキップ';
      session.step = STEPS.BIRTHPLACE;
      sessions.set(userId, session);

      await pushWithQR(userId,
        `ありがとうございます🌙\n\n` +
        `最後に、生まれた都道府県・地域を教えてください🗾\n` +
        `（例：東京、石川県）\nわからない場合はスキップできます`,
        [{ label: 'スキップ', text: 'スキップ' }]
      );
      break;
    }

    case STEPS.BIRTHPLACE: {
      session.birthplace = text;
      session.step = STEPS.CONFIRM;
      sessions.set(userId, session);

      const d = session.birthday;
      await pushWithQR(userId,
        `以下の内容で送信します✨\n\n` +
        `お名前：${session.name}\n` +
        `生年月日：${d.year}/${pad(d.month)}/${pad(d.day)}（${session.zodiac}）\n` +
        `出生時間帯：${session.timeOfDay}\n` +
        `出生地：${session.birthplace}\n\n` +
        `よろしいですか？`,
        [
          { label: '✓ 送信する',          text: '送信する' },
          { label: '✏️ 最初からやり直す', text: 'やり直す' },
        ]
      );
      break;
    }

    case STEPS.CONFIRM: {
      if (text === '送信する') {
        session.step = STEPS.DONE;
        sessions.set(userId, session);

        await push(userId,
          `ありがとうございます🌙✨\n` +
          `星読みカルテをお届けするまで、\nしばらくお待ちください。\n\n` +
          `通常2〜3日以内にこちらからご連絡します。\n` +
          `楽しみにお待ちください🔮`
        );

        await notifyAdmin(session);

      } else {
        sessions.delete(userId);
        await sendWelcome(userId);
      }
      break;
    }
  }
}

// ── ウェルカム ────────────────────────────────────────
async function sendWelcome(userId) {
  sessions.set(userId, { step: STEPS.NAME });
  await push(userId,
    `✨ 星読みカルテへようこそ🌙\n\n` +
    `あなたの生まれ持った星のパターンから、\n` +
    `人間関係の傾向を言語化してお届けします。\n\n` +
    `まず、お名前またはニックネームを教えてください😊`
  );
}

// ── 管理者通知 ────────────────────────────────────────
async function notifyAdmin(session) {
  if (!ADMIN_LINE_USER_ID) return;
  const d = session.birthday;
  await client.pushMessage(ADMIN_LINE_USER_ID, {
    type: 'text',
    text:
      `📋 新しい診断申込！\n\n` +
      `お名前：${session.name}\n` +
      `生年月日：${d.year}/${pad(d.month)}/${pad(d.day)}\n` +
      `星座：${session.zodiac}\n` +
      `出生時間帯：${session.timeOfDay}\n` +
      `出生地：${session.birthplace}\n` +
      `受付：${new Date().toLocaleString('ja-JP', { timeZone: 'Asia/Tokyo' })}`,
  });
}

// ── ユーティリティ ────────────────────────────────────
async function push(userId, text) {
  return client.pushMessage(userId, { type: 'text', text });
}

async function pushWithQR(userId, text, buttons) {
  return client.pushMessage(userId, {
    type: 'text',
    text,
    quickReply: {
      items: buttons.map(b => ({
        type: 'action',
        action: { type: 'message', label: b.label, text: b.text },
      })),
    },
  });
}

function parseBirthday(text) {
  const clean = text.replace(/[年月\/\-\.]/g, '/').replace(/日/g, '');
  const parts = clean.split('/').filter(Boolean);
  let y, m, d;
  if (parts.length === 3) {
    [y, m, d] = parts.map(Number);
  } else if (/^\d{8}$/.test(clean)) {
    y = +clean.slice(0,4); m = +clean.slice(4,6); d = +clean.slice(6,8);
  } else return null;
  if (!y || y < 1900 || y > 2020) return null;
  if (!m || m < 1 || m > 12) return null;
  if (!d || d < 1 || d > 31) return null;
  return { year: y, month: m, day: d };
}

function getZodiac(month, day) {
  const signs = [
    [[3,21],[4,19],'牡羊座'],  [[4,20],[5,20],'牡牛座'],
    [[5,21],[6,21],'双子座'],  [[6,22],[7,22],'蟹座'],
    [[7,23],[8,22],'獅子座'],  [[8,23],[9,22],'乙女座'],
    [[9,23],[10,23],'天秤座'], [[10,24],[11,22],'蠍座'],
    [[11,23],[12,21],'射手座'],[[12,22],[1,19],'山羊座'],
    [[1,20],[2,18],'水瓶座'],  [[2,19],[3,20],'魚座'],
  ];
  for (const [[sm,sd],[em,ed],name] of signs) {
    if ((month===sm&&day>=sd)||(month===em&&day<=ed)) return name;
  }
  return '山羊座';
}

function pad(n) { return String(n).padStart(2,'0'); }

// ── 起動 ─────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`🌙 Bot起動 port:${PORT}`));
